//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by resource.rc
//
#define IDR_COPY_PS                     101
#define IDR_FULLSCREEN_VS               102
#define IDR_IMGUI_PS_3_0                103
#define IDR_IMGUI_PS_4_0                104
#define IDR_IMGUI_PS_SPIRV              105
#define IDR_IMGUI_VS_3_0                106
#define IDR_IMGUI_VS_4_0                107
#define IDR_IMGUI_VS_SPIRV              108
#define IDR_MIPMAP_CS                   109
#define IDB_MAIN_ICON                   110
#define IDR_LICENSE_GL3W                701
#define IDR_LICENSE_IMGUI               702
#define IDR_LICENSE_MINHOOK             703
#define IDR_LICENSE_RESHADE             704
#define IDR_LICENSE_SPIRV               705
#define IDR_LICENSE_STB                 706
#define IDR_LICENSE_UTFCPP              707
#define IDR_LICENSE_VMA                 708
#define IDR_LICENSE_VULKAN              709

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        111
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           111
#endif
#endif
