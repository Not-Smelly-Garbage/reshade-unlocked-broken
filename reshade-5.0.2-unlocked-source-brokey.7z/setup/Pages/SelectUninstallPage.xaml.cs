﻿/*
 * Copyright (C) 2021 Patrick Mours
 * SPDX-License-Identifier: BSD-3-Clause
 */

using System.Windows.Controls;

namespace ReShade.Setup.Pages
{
	public partial class SelectUninstallPage : Page
	{
		public SelectUninstallPage()
		{
			InitializeComponent();
		}
	}
}
